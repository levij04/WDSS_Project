<?php
define("DB_HOST", "localhost");
define("DB_USER", "levi");
define("DB_PASS", "");
define("DB_NAME", "books");
