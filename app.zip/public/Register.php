<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>
        Library
    </title>
    <link href="CSS/Layout.css" rel="stylesheet" type="text/css"/>
    <link href="CSS/Menu.css" rel="stylesheet" type="text/css"/>

</head>

<body>

<div id="Holder">
    <div id="Header"></div>
    <div id="NavBar">
        <nav>
            <ul>
                <li><a href="#">Login</a></li>
                <li><a href="#">Register</a></li>
                <li><a href="#">Forgot Password</a></li>
            </ul>
        </nav>
    </div>


    <div id="Footer"></div>
</div>
</body>
</html>
<?php


